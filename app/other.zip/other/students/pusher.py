import pusher

pusher_client = pusher.Pusher(
  app_id='1385502',
  key='8ac282d8b5fbf6b803e7',
  secret='50c81d7cfb6d1f939d19',
  cluster='ap2',
  ssl=True
)